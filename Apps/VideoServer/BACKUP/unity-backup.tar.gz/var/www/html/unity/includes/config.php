<?php
// mySQL database credentials are defined below

$hostname_unity = 'localhost';

$username_unity = 'unity-sql';

$password_unity = 'pl@y1nl1vs';

$database_unity = 'unity-core';

$unity = mysql_pconnect($hostname_unity, $username_unity, $password_unity) or trigger_error(mysql_error(),E_USER_ERROR);

$host='{localhost/notls/imap4}INBOX';
$user='sandbox@unity.ic3d.tv';
$pass='password';

$TNEF = "/usr/bin/tnef --overwrite --number-backups";

$TNEF_LIST = "/usr/bin/tnef -t";

$FILEPROGRAM = "/usr/bin/file -b";
			
$TEMPDIR_BASE=$_SERVER['DOCUMENT_ROOT']."/sandbox/comms/tmp/";


// LIVS FEATURES
		// Get the base Unity Path
		$get_url = $_SERVER['REQUEST_URI'];
		$pieces = explode("/", $get_url);
		$location = $pieces[1]; // piece1
		
		$stream_port = '1935';
		#$stream_1_IP = $_SERVER['SERVER_NAME'];		
		$stream_1_IP = 'ec2-50-17-71-94.compute-1.amazonaws.com';
		$stream_1_url = 'live';
		$stream_1_file = 'STREAM1.stream';
		
		#$stream_2_IP = $_SERVER['SERVER_NAME'];
		$stream_2_IP = 'ec2-50-17-71-94.compute-1.amazonaws.com';
		$stream_2_url = 'live';
		$stream_2_file = 'STREAM1.stream';		
		
		// Stream #1
		// $Stream_1_Flash_url = "mobile.php?i=Stream_1";
		// $Stream_1_iOS_url = "http://50.17.200.191:1935/live/live.stream/playlist.m3u8";
		// $Stream_1_default_url = "rtsp://50.17.200.191:1935/live/live.stream";

?>
