<?php
// mySQL database credentials are defined below
$dbhost = 'localhost';
$dbuser = 'unity-sql';
$dbpass = 'pl@y1nl1vs';
$dbname = 'unity-core';
?>
