#!/usr/bin/perl
use Getopt::Std;
use POSIX;
use Time::Local;

### Define our client include file
$opt_c = "0";
getopt('c:');
chomp($opt_c);

### We have to get/require a config file to continue
if(-e "/home/videouser/VIDEO_SERVER/CONFIGS/$opt_c"){

require "/home/videouser/VIDEO_SERVER/INCLUDE/MasterConfig.inc";
require "/home/videouser/VIDEO_SERVER/CONFIGS/$opt_c";

### Define these things ahead of time
my $streamStart = 1;
my $file = 0;
our $latest_file = '';
our $buffer = 0;
our $que_position = 0;
our $stream = $feed;

### Clean up any old sorting
runArchiveSort($opt_c);

### Start our never ending loop and nvr eq 0.. ie once started this process must be killed from cmd line
while($streamStart == 1)
{
	
### Get the current time for matience
($sec, $min, $hr, $day, $month, $year, $dayOfWeek, $dayOfYear, $daylightSavings) = localtime();
$year = 1900 + $year;
$month = sprintf("%2d", $month+1);
$month =~ tr/ /0/;
$day = sprintf("%2d", $day);
$day =~ tr/ /0/;
$hr = sprintf("%2d", $hr);
$hr =~ tr/ /0/;
$min = sprintf("%2d", $min);
$min =~ tr/ /0/;

### Call our offsets each round - change on the fly
require "/home/videouser/VIDEO_SERVER/INCLUDE/OFFSET.inc";
our $pause_offset = $stream_offset;
our $sample_offset = $log_offset;
our $time_offset = $buffer_offset;

    ### Make Buffer Adjustment
	$buffer_pause = ($buffer/10)+$pause_offset-($time_offset/10);
	 if($buffer_pause < 6){
		$buffer_pause = 6;
	 }elsif($buffer_pause > 8){
		$buffer_pause = 8;
	 }
	
	### Sleep enough time to make zen
	print "\nDelay (".$buffer_pause.")\n"; 
	sleep $buffer_pause;
    
	### Eliminate any and all spacing and extra chars
    chomp ($file);
    chomp ($latest_file);

	### If latest file is blank, get one and loop back arround try again
	if ($latest_file eq '') {
	
		our $latest_file = `/bin/su - root -c\"ls -1tr | find $ftp$feed"_"* -type f -mmin -3 2>/dev/null | tail -1 | head -1\"`;
		print "\n No Media Found -> Default Clip \n";
		# `echo -e '*PLAY-LIST*\n"/usr/local/movies/default2.mp4",5' >> /var/streaming/playlists/$playlist/$playlist.insertlist`;
	
	}else{

		### Change latest file to working file
		$file = $latest_file;
		@get_date_parts = split(/_/, $file);
		$this_date = @get_date_parts[1];
		$get_time = @get_date_parts[2];
		
		### Buffer out the clip
		$offset = process_buffer($this_date, $this_time);
		print "\nBufferSet(".$buffer.")\n";
        	
        ### If no error move on to the Darwin que
        if($offset != 'error'){
            
            ### Set the playlist item
        	$item = $ftp.$feed."_".$offset;
        	
            ### Wait till the file is unlocked
            # $count = 0;
            # `lsof -w $item`;
            # while($? == 0){
            #	last if $count == 2;
            #    $count++;
            #    sleep 1;
            #    `lsof -w $item`;
            #    print $count . " - ";
            # }
            # if($count < 2){
			#	`chmod 0755 $item`;
			# }
			
			### Get the current buffer length
			$file = $item;
			$get_buffer = get_buffer_length();
			
			### If the buffer has run out then reset the que
	        if($get_buffer > $buffer){
	            ### Reset To Default
	        	our $buffer = $get_buffer + $time_offset;
	        	our $que_position = 0;
	        	### Play Buffer Clip
	            print "\n Increase Playlist Buffer - Using (".$buffer.") -> ";
				# `echo -e '*PLAY-LIST*\n"/usr/local/movies/default2.mp4",5' >> /var/streaming/playlists/$playlist/$playlist.insertlist`;			
					
			}else{
	 			### Proceed to the playlist que
	            print "\n Insert Darwin Playlist - Using Buffer (".$stream.") -> ";
	
	            ### If the last clip is the same as this clip we have to eat some buffer
	            if( $last_offset eq $offset ){
						### Adjust Buffer
						our $buffer = $buffer - 10;
						print "(using buffer)";
						### Get the current clip to process with buffer adjustment
						$offset = process_buffer($this_date, $this_time);
						
				}else{
					### No buffer adjustment needed but change the offset
					# $offset = process_buffer($this_date, $this_time, $buffer);
					$last_offset = $offset;
					
				}
				### Send the clip to the Darwin que
				sendToDarwin($offset, $stream);
				### Move to the next clip in line
				our $que_position = $que_position + 10;
			
			}			

        }else{
            ### There was a problem reset everything
			our $latest_file = '';
			our $que_position = 0;
			our $buffer = 0;
	        ### Play Buffer Clip
	        print "\n Playlist Buffer Error (Reset)\n\n ";
			# `echo -e '*PLAY-LIST*\n"/usr/local/movies/default2.mp4",5' >> /var/streaming/playlists/$playlist/$playlist.insertlist`;
							
		}

	}

    ### At the end of each loop look to clean up a few files
    cleanUpPlaylist();
		
	if($min == 05 || $min == 10 || $min == 15 || $min == 20 || $min == 25 || $min == 30 || $min == 35 || $min == 40 || $min == 45 || $min == 50 || $min == 55){
		### Kick The Sorting Of LIVS
		runArchiveSort($opt_c);
		runProxy();

	}

	### Run our Maint Script
	if($hr == 23 && $min == 55){

		runMaint();

	}elsif($hr == 23 && $min == 59){

		cleanMaint();

	}

}

}else{

print "*** Invalid Config Specified ***\n*** Use -c CONFIG_FILE_NAME.inc ***\n";

}

########################################
######## VIDEO SERVER FUNCTIONS ########
########################################

sub process_buffer($this_date, $get_time){
	require "/home/videouser/VIDEO_SERVER/INCLUDE/MasterConfig.inc";
        @clean_time = split(/.mp4/,$get_time);
        $this_time = @clean_time[0];
        $this_year = substr($this_date, 0, 4);
        $this_month = substr($this_date, 4, 2)-1;
        $this_day = substr($this_date, 6, 2);
        $this_hour = substr($this_time, 0, 2);
        $this_min = substr($this_time, 2, 2);
        $this_sec = substr($this_time, 4, 2);
        $this_clip = timelocal($this_sec, $this_min, $this_hour, $this_day, $this_month, $this_year);
        $this_buffer = $this_clip - $buffer + $que_position;
        $new_clip = strftime( "%Y%m%d_%H%M%S", localtime($this_buffer) );
        my $buffer_clip = $ftp.$feed."_".$new_clip.".mp4";
        if (-e $buffer_clip) {
		return $new_clip.".mp4";
        }else{
		return 'error';
        }

}

### Test the average network speed
sub get_buffer_length(){
my $avg_upload = `/bin/su - root -c\"tail -$sample_offset /var/log/vsftpd.log | grep "OK UPLOAD"\"`;
@last_ten = split(/\n/, $avg_upload);
$total_size=0;
$total_avg=0;
$total_items=0;
foreach $item(@last_ten){
        @get_avg = split(/,/, $item);
        $item_size = @get_avg[2];
        $item_avg = @get_avg[3];
        $item_size =~ s/ bytes//g;
        $item_avg =~ s/Kbyte\/sec//g;
        $total_size = $total_size + $item_size;
        $total_avg = $total_avg + $item_avg;
        $total_items = $total_items + 1;
}
print $total_size.":".$toal_items;
$avg_ksize = ($total_size/128)/$total_items;
$avg_ksec = $total_avg/$total_items;
	if($total_avg > 0){
		$result = $avg_ksize/$avg_ksec;
		$buffer_length = round_buffer_length($result);
		# print $avg_upload;
		print "\n\nNetwork Stats: (avg)".$avg_ksec. "(size)".$avg_ksize. "(buffer)".$buffer_length."(global)".$buffer;
		return $buffer_length;
	}else{
		$buffer_length = 0;
		return $buffer_length;
		
	}
}
sub round_buffer_length($) {

        my $n = int shift;

        if(($n % 10) == 0) {
                $n = 10;
                return($n);
        } else {
                my $sign = 1;
                if($n < 0) { $sign = 0; }

                $n = int ($n / 10);
                $n *= 10;
                if($sign) {
                        $n += 10;
                }
                return($n);
        }
        return(-1);
}

### SEND TO DARWIN PLAYLIST ###
sub sendToDarwin($offset, $stream){
	require "/home/videouser/VIDEO_SERVER/CONFIGS/$opt_c";

	$file = $ftp.$stream."_".$offset;
	 
	if(-d "/usr/local/movies/videoserver_tmp/$playlist"){
        ### FEED TEMP DIR EXISTS
    }else{
        `mkdir /usr/local/movies/videoserver_tmp/$playlist`;
        `chmod 0755 /usr/local/movies/videoserver_tmp/$playlist`;
        `chown qtss:qtss /usr/local/movies/videoserver_tmp/$playlist`;
    }

        # my $file=shift;

        ### Get the file name
        @name = split(/$ftp/, $file);
        $this_file = @name[1];
        $this_playlist = "/var/streaming/playlists/$playlist/$playlist.log";

	if(-e "/home/livs/@name[1]"){
			
        ### Copy to the broadcast tmp directroy
        `cp $file "/usr/local/movies/videoserver_tmp/$playlist"`;
		### Safe exit on file error
		$count = 0;
        while(1){
        last if $count == 2;
        $count++;
        last if -e "/usr/local/movies/videoserver_tmp/$playlist/@name[1]";
        }
        
        `chown qtss:qtss "/usr/local/movies/videoserver_tmp/$playlist/@name[1]"`;

        ### Prepare file for streaming
        `/bin/su - root -c\"MP4Box -hint "/usr/local/movies/videoserver_tmp/$playlist/@name[1]"\"`;
		### Safe exit on file error
		$count = 0;
        while(1){
        last if $count == 2;
        $count++;
        last if -e "/usr/local/movies/videoserver_tmp/$playlist/@name[1]";
        }     
        
        ### Finally add to the Playlist que
        `echo -e '*PLAY-LIST*\n"/usr/local/movies/videoserver_tmp/$playlist/@name[1]",5' >> /var/streaming/playlists/$playlist/$playlist.insertlist`;	

		print $file;
	}
		
}

### CLEANUP THE DARWIN TMP FOLDERS ###
sub cleanUpPlaylist{

        ### Do some routine cleanup on the tmp directory
        `find /usr/local/movies/videoserver_tmp/$playlist/*.mp4 -type f -mmin +15 -delete 2>/dev/null`;

}

### RUN ARCHIVE SORT/CLEAN LIVS DIR ###
sub runArchiveSort($opt_c){

	### If processing is already set, leave until its time
	if(-e "/home/videouser/VIDEO_SERVER/TMP/$opt_c.processing"){
	
		### print "*** Archive Is Already Running *** \n";
	
	}else{
	
		### Kick The Archive
		### print "\n\n *** Kicking Archive *** \n";
		`nohup ./ondemand.pl -c $opt_c >/dev/null 2>&1 &`;

	}

}

### RUN FILE PROXY SERVICE ###
sub runProxy(){

                ### Kick The Archive
                ### print "\n\n *** Kicking Archive *** \n";
                `nohup ./proxyservice.pl >/dev/null 2>&1 &`;
}

### RUN BACKUP N MAINT ###
sub runMaint(){

        	### If processing is already set, leave until its time
        	if(-e "/home/videouser/VIDEO_SERVER/TMP/backup.running"){

                	### print "*** Backup Is Already Running *** \n";

        	}else{

                	### Kick The Backup
                	### print "\n\n *** Kicking Archive *** \n";
                	`nohup ./backupsql.pl >/dev/null 2>&1 &`;

        	}

}

### CLEAN MAINT SCRIPT
sub cleanMaint(){

                ### Remove the trigger file
                `rm -rf /home/videouser/VIDEO_SERVER/TMP/backup.running`;

}
